const {
    BN, // Big Number support
    constants, // Common constants, like the zero address and largest integers
    expectEvent, // Assertions for emitted events
    expectRevert, // Assertions for transactions that should fail
    time,
  } = require("@openzeppelin/test-helpers");
  
  const truffleAssert = require("truffle-assertions");
  const { assert, expect } = require("chai");
  const { increase } = require("@openzeppelin/test-helpers/src/time");
  const Remit = artifacts.require("Remit");
  const RemitFarmEth = artifacts.require("RemitVaultFarmEth");
  const RemitFarmDai = artifacts.require("RemitVaultFarmDai");
  const RemitFarmUsdt = artifacts.require("RemitVaultFarmUsdt");
  const RemitLP =  artifacts.require("RemitLP");
  
  require("chai").use(require("chai-bignumber")(BN)).should();
  
  
  contract("Remit Farm", () => {
    it("Should deploy smart contract properly", async () => {
      const remit = await Remit.deployed();
      const remitfarmeth = await RemitFarmEth.deployed();
      const remitfarmdai = await RemitFarmDai.deployed();
      const remitfarmusdt = await RemitFarmUsdt.deployed();
      const Lp_Eth = await RemitLP.deployed();
      const Lp_Dai = await RemitLP.deployed();
      const Lp_Usdt = await RemitLP.deployed();


      assert(remit.address !== "");
      assert(remitfarmeth.address !== "");
      assert(remitfarmdai.address !== "");
      assert(remitfarmusdt.address !== "");
      assert(Lp_Eth.address !== "");
      assert(Lp_Dai.address !== "");
      assert(Lp_Usdt.address !== "");
    });
  
    beforeEach(async function () {
      remit = await Remit.new();
      remitfarmeth = await RemitFarmEth.new()
      remitfarmdai = await RemitFarmDai.new();
      remitfarmusdt = await RemitFarmUsdt.new();
      Lp_Eth = await RemitLP.new();
      Lp_Dai = await RemitLP.new();
      Lp_Usdt = await RemitLP.new();
      accounts = await web3.eth.getAccounts();
    });
  
 
  
    describe("[Testcase 1: To deposit  tokens ]", () => {
      it("Deposit ", async () => {
        await remit.setFarmAddress([remitfarmeth.address,remitfarmdai.address,remitfarmusdt.address]);
        await remitfarmeth.setRewardTokenAddress(remit.address);
        await remitfarmeth.setDepositTokenAddress(Lp_Eth.address);
        await Lp_Eth.transfer(accounts[2],web3.utils.toWei("100","ether"));
        await Lp_Eth.approve(remitfarmeth.address,web3.utils.toWei("55","ether"),{from:accounts[2]});
        await remitfarmeth.deposit(web3.utils.toWei("20","ether"),{from : accounts[2]});
        await remitfarmeth.deposit(web3.utils.toWei("10","ether"),{from : accounts[2]});
        var actual = await remitfarmeth.depositedTokens( accounts[2]);
        var expected = web3.utils.toWei("30","ether");
        assert.equal(actual,expected);

        await time.increase(time.duration.days(45));

        await remitfarmeth.deposit(web3.utils.toWei("15","ether"),{from : accounts[2]});
        
        actual = await remit.stakeFarmSupply();
        expected = web3.utils.toWei("350000","ether");
        assert.notEqual(actual,expected);
  
      });
    });

    describe("[Testcase 2: To deposit non trusted tokens ]", () => {
        it("Deposit ", async () => {
          await remit.setFarmAddress([remitfarmeth.address,remitfarmdai.address,remitfarmusdt.address]);
          await remitfarmeth.setRewardTokenAddress(remit.address);
          await Lp_Eth.transfer(accounts[6],web3.utils.toWei("100","ether"));
          await Lp_Eth.approve(remitfarmeth.address,web3.utils.toWei("100","ether"),{from:accounts[6]});
          try{
            await remitfarmeth.deposit(web3.utils.toWei("80","ether"),{from : accounts[6]});
          }
          catch{
            var actual = await remitfarmeth.depositedTokens( accounts[6]);
            var expected = 0;
            assert.equal(actual,expected);
          }
        });

    describe("[Testcase 3: To withdraw tokens ]", () => {
        it("withdraw", async () => {
          
            await remit.setFarmAddress([remitfarmeth.address,remitfarmdai.address,remitfarmusdt.address]);
            await remitfarmeth.setRewardTokenAddress(remit.address);
            await remitfarmeth.setDepositTokenAddress(Lp_Eth.address);
            await Lp_Eth.transfer(accounts[2],web3.utils.toWei("100","ether"));
            await Lp_Eth.approve(remitfarmeth.address,web3.utils.toWei("80","ether"),{from:accounts[2]});
            await remitfarmeth.deposit(web3.utils.toWei("39","ether"),{from : accounts[2]});
            await remitfarmeth.deposit(web3.utils.toWei("20","ether"),{from : accounts[2]});

            await time.increase(time.duration.days(56));
            
            await remitfarmeth.withdraw(web3.utils.toWei("18","ether"),{from : accounts[2]});

            var actual = await remitfarmeth.totalTokens();
            var expected = web3.utils.toWei("41","ether");
            assert.equal(actual,expected);
            });
          });
      });

      
      describe("[Testcase 4: To withdraw tokens before cliff time ]", () => {
        it("withdraw", async () => {
        
          await remit.setFarmAddress([remitfarmeth.address,remitfarmdai.address,remitfarmusdt.address]);
          await remitfarmeth.setRewardTokenAddress(remit.address);
          await remitfarmeth.setDepositTokenAddress(Lp_Eth.address);
          await Lp_Eth.transfer(accounts[4],web3.utils.toWei("100","ether"));
          await Lp_Eth.approve(remitfarmeth.address,web3.utils.toWei("100","ether"),{from:accounts[4]});
          await remitfarmeth.deposit(web3.utils.toWei("89","ether"),{from : accounts[4]});
          try{
            await remitfarmeth.withdraw(web3.utils.toWei("65","ether"),{from : accounts[4]});
          }
          catch{
          }
          var actual = await remitfarmeth.totalEarnedTokens(accounts[4]);
          var expected = 0;
          assert.equal(actual,expected);
        });
  });

    describe("[Testcase 5: To perform emergency withdraw ]", () => {
      it("Emergency Withdraw", async () => {
       
        await remit.setFarmAddress([remitfarmeth.address,remitfarmdai.address,remitfarmusdt.address]);
        await remitfarmeth.setRewardTokenAddress(remit.address);
        await remitfarmeth.setDepositTokenAddress(Lp_Eth.address);
        await Lp_Eth.transfer(accounts[2],web3.utils.toWei("60","ether"));
        await Lp_Eth.approve(remitfarmeth.address,web3.utils.toWei("55","ether"),{from:accounts[2]});
        await remitfarmeth.deposit(web3.utils.toWei("40","ether"),{from : accounts[2]});

        await time.increase(time.duration.hours(84));
       
        await remitfarmeth.emergencyWithdraw(web3.utils.toWei("28","ether"),{from : accounts[2]});
        var actual = await remitfarmeth.totalEarnedTokens(accounts[2]);
        var expected = 0;
        assert.equal(actual,expected);
      });
    });


    describe("[Testcase 6: To deposit and withdraw ]", () => {
      it("Deposit and Withdraw Tokens", async () => {
       
        await remit.setFarmAddress([remitfarmeth.address,remitfarmdai.address,remitfarmusdt.address]);
        await remitfarmeth.setRewardTokenAddress(remit.address);
        await remitfarmeth.setDepositTokenAddress(Lp_Eth.address);

        await Lp_Eth.transfer(accounts[5],web3.utils.toWei("60","ether"));
        await Lp_Eth.approve(remitfarmeth.address,web3.utils.toWei("55","ether"),{from:accounts[5]});
        await remitfarmeth.deposit(web3.utils.toWei("40","ether"),{from : accounts[5]});

        await Lp_Eth.transfer(accounts[6],web3.utils.toWei("45","ether"));
        await Lp_Eth.approve(remitfarmeth.address,web3.utils.toWei("30","ether"),{from:accounts[6]});
        await remitfarmeth.deposit(web3.utils.toWei("25","ether"),{from : accounts[6]});

        await remitfarmeth.deposit(web3.utils.toWei("10","ether"),{from : accounts[5]});

        await time.increase(time.duration.days(56));
            
        await remitfarmeth.withdraw(web3.utils.toWei("18","ether"),{from : accounts[5]});

        var actual = await remit.stakeFarmSupply();
        var expected = web3.utils.toWei("350000","ether");
        assert.notEqual(actual,expected);
  
      });
    });

      describe("[Testcase 7: To deposit and withdraw in two different pools ]", () => {
        it("Deposit and Withdraw Tokens", async () => {
          await remit.setFarmAddress([remitfarmeth.address,remitfarmdai.address,remitfarmusdt.address]);
          await remitfarmdai.setRewardTokenAddress(remit.address);
          await remitfarmdai.setDepositTokenAddress(Lp_Dai.address);
          await remitfarmusdt.setRewardTokenAddress(remit.address);
          await remitfarmusdt.setDepositTokenAddress(Lp_Usdt.address);
  
          await Lp_Dai.transfer(accounts[8],web3.utils.toWei("60","ether"));
          await Lp_Dai.approve(remitfarmdai.address,web3.utils.toWei("55","ether"),{from:accounts[8]});

          await Lp_Usdt.transfer(accounts[8],web3.utils.toWei("60","ether"));
          await Lp_Usdt.approve(remitfarmusdt.address,web3.utils.toWei("55","ether"),{from:accounts[8]});

          await remitfarmusdt.deposit(web3.utils.toWei("40","ether"),{from : accounts[8]});
          await remitfarmdai.deposit(web3.utils.toWei("25","ether"),{from : accounts[8]});

          var dvs = await remitfarmusdt.getPendingDivs(accounts[8]);
          console.log(dvs.toString());

          await time.increase(time.duration.days(56));

           dvs = await remitfarmusdt.getPendingDivs(accounts[8]);
          console.log(dvs.toString());
              
          await remitfarmusdt.withdraw(web3.utils.toWei("27","ether"),{from : accounts[8]});
          await remitfarmdai.withdraw(web3.utils.toWei("18","ether"),{from : accounts[8]});
  
          var actual = await remit.stakeFarmSupply();
          var expected = web3.utils.toWei("350000","ether");
          assert.notEqual(actual,expected);

           dvs = await remitfarmusdt.getPendingDivs(accounts[8]);
          console.log(dvs.toString());
    
        });
  });
});
  