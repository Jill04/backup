var Remit = artifacts.require("Remit.sol");
var RemitFarmEth = artifacts.require("RemitVaultFarmEth.sol");
var RemitFarmDai = artifacts.require("RemitVaultFarmDai.sol");
var RemitFarmUsdt = artifacts.require("RemitVaultFarmUsdt.sol");
var RemitLP = artifacts.require("RemitLP.sol");
var RemitStake = artifacts.require("RemitStaking");
var RemitPreSale = artifacts.require("RemitPresale");

module.exports = async function(deployer)
{
	 var accounts = await web3.eth.getAccounts();
	 await deployer.deploy(Remit);
	 await deployer.deploy(RemitFarmEth);
	 await deployer.deploy(RemitFarmUsdt);
	 await deployer.deploy(RemitFarmDai);
	 await deployer.deploy(RemitLP);
	 await deployer.deploy(RemitStake,Remit.address);
	 await deployer.deploy(RemitPreSale,Remit.address,accounts[9]);
}
