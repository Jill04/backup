const NFTCards = artifacts.require("./NFTCards.sol");
const JungleToken = artifacts.require("./JungleToken.sol");
const Proxy = artifacts.require("./EternalStorageProxy.sol");

module.exports = async function(deployer)
{
	 await deployer.deploy(JungleToken);
	//  await deployer.deploy(NFTCards);
	//  await deployer.deploy(Proxy);
};	

//const { deployProxy } = require('@openzeppelin/truffle-upgrades');

//const AdminBox = artifacts.require('AdminBox');

// module.exports = async function (deployer) {
//   // await deployProxy(JungleToken, ['0x03326793A092136609Df7Ae47CB160aa85c39BBa'], { deployer, initializer: 'initialize' });
  
// };