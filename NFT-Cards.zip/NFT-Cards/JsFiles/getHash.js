const { imageHash } = require('image-hash');
// const ipfs = require('ipfs')
//const request = require('request');
var sha256File = require('sha256-file');
//const fetch = require('node-fetch');

// remote file simple


module.exports = async callback => {
    const fs = require('fs');
const https = require('https');
  
// URL of the image
const url = 'https://ipfs.io/ipfs/QmVEGtJGAKmYZyYMQAHqebPMfasKa7WY2urFuaCse1zkWf';
__dirname="D:/Projects/1.Skyweaver/JsFiles/"
https.get(url,(res) => {
    // Image will be stored at this path
    const path = `${__dirname}img.jpeg`; 
    const filePath = fs.createWriteStream(path);
    res.pipe(filePath);
    filePath.on('finish',() => {
        filePath.close();
        console.log('Download Completed'); 
    })
})
    let name = 'JsFiles/img.jpeg';
    sha256File(name, function (error, sum) {
        if (error) return console.log(error);
        console.log(sum)
    });
 
}