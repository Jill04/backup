const NFTcards = artifacts.require("./NFTcards.sol");
//const NFTcardsWith20Nfts = artifacts.require(".NftCardsWith20Nfts.sol");

const JungleToken = artifacts.require("./JungleToken.sol");

const { expect } = require('chai');
const { reverts } = require('truffle-assertions');
const truffleAssert = require('truffle-assertions');
contract("NFTcards", accounts => {
  const [deployerAccount, buyer, userThird] = accounts;

  beforeEach(async () => {
    JungleTokenInstance = await JungleToken.new();
    instance = await NFTcards.new(JungleTokenInstance.address,1627065000);
    await JungleTokenInstance.setNftCardAddress(instance.address);

  });

  it("Testcase 1 :should mint nfts.", async () => {
    await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16", "ether") });
    let bal = await instance.balanceOf(buyer);
    expect(bal.toString()).to.equals("2");
  });


  it("Testcase 2 : Nft buyer should get 500 Jungle token amount per NFT ", async () => {
    await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16", "ether") });
    let bal = await JungleTokenInstance.balanceOf(buyer);
    expect(bal.toString()).to.equals(web3.utils.toWei("1000", "ether"));

  });
  it("Testcase 3 : Should revert if msg.value sent is not enough.", async () => {
    await truffleAssert.reverts(instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.08", "ether") }));
  });

  it("Testcase 4 : Owner can withdraw all ethers.", async () => {

    let bal = await web3.eth.getBalance(deployerAccount);

    await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16", "ether") });
    await instance.withdraw({ from: deployerAccount });

    let balAfter = await web3.eth.getBalance(deployerAccount);
    expect(balAfter).to.not.equals(bal);

  });

  it("Testcase 5 : Anyone without owner can't withdraw ethers from contract.", async () => {
    await truffleAssert.reverts(instance.withdraw({ from: userThird }));

  });

  //change provenance
  it("Testcase 6 : owner can change provenance", async () => {
    await instance.changeProvenace("0x2B9C48448CE78a92f993ACe5bEED165b725039fb", { from: deployerAccount });
    expect(await instance.PROVENANCE()).to.equals("0x2B9C48448CE78a92f993ACe5bEED165b725039fb");
  });
  it("Testcase 7 : Should revert if msg.sender is not owner while changing provenance", async () => {
    await truffleAssert.reverts(instance.changeProvenace("0x2B9C48448CE78a92f993ACe5bEED165b725039fb", { from: userThird }));

  });

  //change Name
  it("Testcase 8 : Owner of NFT can change name of NFT", async () => {
    await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16", "ether") });

    let OldNameOfNft = await instance.tokenNameByIndex(0);
    await instance.changeName("0", "name1", { from: buyer });
    let NewNameOfNft= await instance.tokenNameByIndex(0);
    expect(NewNameOfNft).to.not.equals(OldNameOfNft);

  });
  it("Testcase 9 : Should revert if msg.sender is not owner of NFT, while changing name", async () => {
    await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16", "ether") });

    await truffleAssert.reverts(instance.changeName("0", "name2", { from: userThird }));

  });

  //change Price
  it("Testcase 10 : owner can change price of NFT", async () => {
    await instance.changePrice(web3.utils.toWei("4.5", "ether"), { from: deployerAccount });
    let price = await instance.NFTPrice();
    expect(price.toString()).to.equals(web3.utils.toWei("4.5", "ether"));

  });
  it("Testcase 11 : Should revert if msg.sender is not owner while changing price", async () => {
    await truffleAssert.reverts(instance.changePrice(web3.utils.toWei("4.5", "ether"), { from: userThird }));

  });

  it("Testcase 12 : Should revert if anyone tries to buy more Nfts than 20", async () => {
    await truffleAssert.reverts(instance.mintNFT(21, { from: buyer, value: web3.utils.toWei("0.0001974","ether")}));
  });

  it("Testcase 13 : Should revert if anyone tries to buy 0 Nfts with mintNft() function", async () => {
    await truffleAssert.reverts(instance.mintNFT(0, { from: buyer, value: web3.utils.toWei("0","ether")}));
  });

  it("Testcase 14 : Reverts if length of name string entered for changeName() is bigger than 25",async ()=>{
    await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16","ether")});
    await truffleAssert.reverts(instance.changeName("0","a1234567891234567891234"));
  });

  //is name reserved
  it("Testcase 15 : Reverts if someone tries to set already reserved name to another NFT",async ()=>{
    await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16","ether")});
    await instance.changeName("0","abcd",{from : buyer});
    await truffleAssert.reverts(instance.changeName("1","abcd",{from : buyer}));
  });
  
  it("Testcase 16 : Reverts if new name is same as current one.",async ()=>{
    await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16","ether")});
    await instance.changeName("0","abcd",{from : buyer});
    await truffleAssert.reverts(instance.changeName("0","abcd",{from : buyer}));
  });

  it("Testcase 17 : Can breed two cards.",async ()=>{
    await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16","ether")});
    await instance.breed("0","1",{from : buyer});
    let totalSupply= await instance.totalSupply();
    expect(totalSupply.toString()).to.equals("3")
  });

  it("Testcase 18 : Ownly owner can breed their cards.",async ()=>{
    await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16","ether")});
    await truffleAssert.reverts(instance.breed("0","1",{from : userThird}));
  });

  it("Testcase 19 : Revert if user tries to breed unexisted NFTs.",async ()=>{
    await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16","ether")});
    await truffleAssert.reverts(instance.breed("0","2",{from : userThird}));
  });
  

  //change MAX_NFT_SUPPLY to 20 before running this test
  // it("Testcase 20 : Reverts if sale has already ended.",async ()=>{
  //   await instance.mintNFT(20, { from: buyer, value: web3.utils.toWei("1.6","ether")});
  //   let a=await instance.MAX_NFT_SUPPLY();
  //   console.log(a.toString());
  //   await truffleAssert.reverts(instance.mintNFT(1, { from: buyer, value: web3.utils.toWei("0.08","ether")}));
  // });
});
