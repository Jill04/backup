const NFt_v0 = artifacts.require('NFTCards')
const Jungle_v0 = artifacts.require('JungleToken')
const Registry = artifacts.require('VProxy')
const Proxy = artifacts.require('UpgradeabilityProxy')

contract('Upgradeable', function ([sender, receiver]) {

  it('should work', async function () {
    const impl_jung = await Jungle_v0.new()
    const impl_v1_0 = await NFt_v0.new(impl_jung.address, 1627049295)
    
    accounts = await web3.eth.getAccounts();

    const registry = await Registry.new()
    await registry.addVersion("1", impl_v1_0.address)
    //await registry.addVersion("1.1", impl_v1_1.address)
    try{
        await registry.createProxy("1")
    }
    
   catch(e){
    console.log(e)
   }
    //const {proxy} = logs.find(l => l.event === 'ProxyCreated').args

    //await NFt_v0.at(proxy).mintNFT(1,{value:web3.utils.toWei("0.08","ether"), from:accounts[6]})

    // await Proxy.at(proxy).upgradeTo("1.1")

    // await TokenV1_1.at(proxy).mint(sender, 100)

    // const transferTx = await TokenV1_1.at(proxy).transfer(receiver, 10, { from: sender })

    // console.log("Transfer TX gas cost using Inherited Storage Proxy", transferTx.receipt.gasUsed);

    // const balance = await TokenV1_1.at(proxy).balanceOf(sender)
    // assert(balance.eq(10190))

  })

})