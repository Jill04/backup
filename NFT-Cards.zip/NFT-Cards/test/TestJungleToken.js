const NFTcards = artifacts.require("./NFTcards.sol");
const JungleToken = artifacts.require("./JungleToken.sol");

const { expect } = require('chai');
const { time } = require("@openzeppelin/test-helpers");
const truffleAssert = require('truffle-assertions');
const { start } = require('ipfs-core/src/components/network');
contract("NFTcards", accounts => {
    const [deployerAccount, buyer, userThird] = accounts;

    beforeEach(async () => {
        JungleTokenInstance = await JungleToken.new();
        instance = await NFTcards.new(JungleTokenInstance.address);
        await JungleTokenInstance.setNftCardAddress(instance.address);

    });

    it("Testcase 1 : Owner/deployer account should able to withdraw tokens for team", async () => {
        await JungleTokenInstance.withdrawTokenForTeam();
        let ownerBalanceAfterWithrawing = await JungleTokenInstance.balanceOf(deployerAccount);
        expect(ownerBalanceAfterWithrawing.toString()).to.equals(web3.utils.toWei("500000", "ether"));
    });
    it("Testcase 2 : Should revert if anyone other than owner try to call withdrawTokenForTeam()", async () => {
        await truffleAssert.reverts(JungleTokenInstance.withdrawTokenForTeam({ from: userThird }));
    });
    it("Testcase 3 : Should revert if owner tries to call withdrawTokenForTeam() before one year completes", async () => {
        await truffleAssert.reverts(JungleTokenInstance.withdrawTokenForTeamAfterYear({ from: deployerAccount }));
    });
    it("Testcase 4 : Should able to change price of the token", async () => {
        await JungleTokenInstance.changePrice(web3.utils.toWei("1", "ether"), { from: deployerAccount });
        let price = await JungleTokenInstance.tokenPrice();
        expect(price.toString()).to.equals(web3.utils.toWei("1", "ether"));

    });
    it("Testcase 5 : Should revert if msg.sender is not owner while changing price", async () => {
        await truffleAssert.reverts(JungleTokenInstance.changePrice(web3.utils.toWei("2", "ether"), { from: userThird }));

    });

    it("Testcase 6 : Should revert if NFT at index has not been minted yet", async () => {
        await truffleAssert.reverts(JungleTokenInstance.claim([0, 1], { from: userThird }));
    });

    it("Testcase 7 : Should revert if caller passes duplicate token index while claiming daily accumulation", async () => {
        await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16", "ether") });
        await truffleAssert.reverts(JungleTokenInstance.claim([0, 0], { from: buyer }));
    });

    it("Testcase 8 : User can't claim accumulation before 1 day happens to user's last claim.", async () => {
        await instance.mintNFT(2, { from: buyer, value: web3.utils.toWei("0.16", "ether") });
        await truffleAssert.reverts(JungleTokenInstance.claim([0, 1], { from: buyer }));
    });

    //mintPublic
    it("Testcase 9 : Anyone except NftCard contract can't call mintforpublic.", async () => {
        await truffleAssert.reverts(JungleTokenInstance.mintforpublic(userThird, 0, { from: userThird }));
    });

    //set nft card address.
    it("Testcase 10 :should able to set/change NFTCard address.", async () => {
        await JungleTokenInstance.setNftCardAddress(instance.address);
        expect(await JungleTokenInstance.cardAddress()).to.equals(instance.address);
    });
    describe('Claiming accumulated tokens.', () => {

        beforeEach(async () => {
            await instance.mintNFT(1, { from: buyer, value: web3.utils.toWei("0.08", "ether") });
            let startTime =await JungleTokenInstance.lastClaim(0);
            OldBal = await JungleTokenInstance.balanceOf(buyer, { from: buyer });
           
            let tt = startTime.toString();
            let day5Time=(await (time.duration.days(5))).toString();
            tt=parseInt(tt);
            day5Time=parseInt(day5Time);
            let sum=tt + day5Time;
            
            
            await time.increaseTo(sum-1);
            
        });
        it("token owner can claim token", async () => {
            
            
            await JungleTokenInstance.claim([0], { from: buyer });
            let bal = await JungleTokenInstance.balanceOf(buyer, { from: buyer });
            
            expect(bal.toString()).to.equals((+OldBal + +web3.utils.toWei("6.8493", "ether")).toString());
        });

    });


});
