const path = require("path");
var HDWalletProvider = require("truffle-hdwallet-provider");
const mnemonic = "afe73da1eda00694d9e18c3bb628eeebc35bdcf69d12a52d7530de1d326c1729";
module.exports = {
  // See <http://truffleframework.com/docs/advanced/configuration>
  // to customize your Truffle configuration!
  contracts_build_directory: path.join(__dirname, "client/src/contracts"),
  networks: {
    develop: {
      port: 8545,
      gas:600000
    },
    kovan: {
      provider: () => new HDWalletProvider(
        mnemonic, `https://kovan.infura.io/v3/328326fd27fb46d39fdce91b8172fe69}`
      ),
      network_id: 42,
    },
  },compilers: {
    solc: {
      version: ">=0.4.0 <=0.8.0"
    }
  }
};
